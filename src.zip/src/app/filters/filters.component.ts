import { Component, OnInit ,ViewChild, Output,EventEmitter} from '@angular/core';
import { ListComponent } from '../list/list.component'
@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css']
})
export class FiltersComponent implements OnInit {
  @ViewChild('listRef', { static: false })
  listRef: ListComponent;
  @Output() value = new EventEmitter<number>();
  // @Output() string_value = new EventEmitter<string>();

  btns: any = [
    '2006','2007','2008','2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','2019','2020'
  ]

  successfulLaunch:any=[
    'true','false'
  ]
  
  constructor() { }

  ngOnInit(): void {
  }

  onClick(btn){
  //  console.log('year')
  let info:any = {
    type:'year',
    value:btn
  }
    this.value.emit(info)

  }
  onSuccessClick(btn){
    console.log()
    let info:any = {
      type:'success',
      value:btn
    }
    this.value.emit(info)

  }
  onLaunchClick(btn){
    let info:any = {
      type:'launch',
      value:btn
    }   
     this.value.emit(info)

  }
}
