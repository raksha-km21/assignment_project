import { Component, OnInit,ViewChild } from '@angular/core';
import { ListComponent } from '../list/list.component'

@Component({
  selector: 'app-dahboard',
  templateUrl: './dahboard.component.html',
  styleUrls: ['./dahboard.component.css']
})
export class DahboardComponent implements OnInit {
  @ViewChild('listRef', { static: false })
  listRef: ListComponent;
  constructor() { }

  ngOnInit(): void {
  }

  getQuery(event){
    this.listRef.setQuery(event);
  }

}
