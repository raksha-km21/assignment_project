import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css'],
})
export class ListComponent implements OnInit {
  data: any;
  constructor() {}

  api: any = 'https://api.spaceXdata.com/v3/launches?limit=100';
  filter: any = 'https://api.spaceXdata.com/v3/launches?limit=100';

  ngOnInit() {
    fetch(this.api)
      .then((response) => response.json())
      .then((json) => {
        this.data = json;
      });
  }

  setQuery(btn){
    if(btn?.type == 'year'){
      this.api= this.filter + '&launch_year='+btn.value
    }
    if(btn?.type == 'success'){
      this.api= this.filter + '&land_success='+btn.value
    }
    if(btn?.type == 'launch'){
      this.api= this.filter + '&launch_success='+btn.value
    }
    console.log(this.api);
    fetch(this.api)
      .then((response) => response.json())
      .then((json) => {
        this.data = json;
      });
  }
}
